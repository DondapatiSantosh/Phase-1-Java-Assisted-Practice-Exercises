public class MergeSort {
    public static void mergeSort(int[] array) {
        if (array.length <= 1) {
            return; // Base case: array with 0 or 1 element is already sorted
        }

        // Divide the array into two halves
        int mid = array.length / 2;
        int[] left = new int[mid];
        int[] right = new int[array.length - mid];
        System.arraycopy(array, 0, left, 0, mid);
        System.arraycopy(array, mid, right, 0, array.length - mid);

        // Recursively sort the two halves
        mergeSort(left);
        mergeSort(right);

        // Merge the sorted halves
        merge(left, right, array);
    }

    public static void merge(int[] left, int[] right, int[] result) {
        int i = 0; // Index for the left array
        int j = 0; // Index for the right array
        int k = 0; // Index for the result array

        while (i < left.length && j < right.length) {
            if (left[i] <= right[j]) {
                result[k] = left[i];
                i++;
            } else {
                result[k] = right[j];
                j++;
            }
            k++;
        }

        // Copy remaining elements from the left array, if any
        while (i < left.length) {
            result[k] = left[i];
            i++;
            k++;
        }

        // Copy remaining elements from the right array, if any
        while (j < right.length) {
            result[k] = right[j];
            j++;
            k++;
        }
    }

    public static void main(String[] args) {
        int[] numbers = { 5, 2, 8, 10, 1, 4 };

        System.out.println("Array before sorting:");
        printArray(numbers);

        mergeSort(numbers);

        System.out.println("Array after sorting:");
        printArray(numbers);
    }

    public static void printArray(int[] array) {
        for (int num : array) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
}
