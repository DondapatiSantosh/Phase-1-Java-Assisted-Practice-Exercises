public class SelectionSort {
    public static void selectionSort(int[] array) {
        int size = array.length;

        for (int i = 0; i < size - 1; i++) {
            int minIndex = i;

            // Find the index of the minimum element in the remaining unsorted part of the array
            for (int j = i + 1; j < size; j++) {
                if (array[j] < array[minIndex]) {
                    minIndex = j;
                }
            }

            // Swap the minimum element with the first element in the unsorted part of the array
            int temp = array[minIndex];
            array[minIndex] = array[i];
            array[i] = temp;
        }
    }

    public static void main(String[] args) {
        int[] numbers = { 5, 2, 8, 10, 1, 4 };

        System.out.println("Array before sorting:");
        printArray(numbers);

        selectionSort(numbers);

        System.out.println("Array after sorting:");
        printArray(numbers);
    }

    public static void printArray(int[] array) {
        for (int num : array) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
}
