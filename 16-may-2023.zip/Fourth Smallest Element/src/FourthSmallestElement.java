import java.util.Arrays;

public class FourthSmallestElement {
    public static void main(String[] args) {
        int[] arr = {9, 2, 5, 1, 7, 6, 3, 8, 4, 10};
        
        int fourthSmallest = findFourthSmallestElement(arr);
        
        System.out.println("Fourth Smallest Element: " + fourthSmallest);
    }
    
    public static int findFourthSmallestElement(int[] arr) {
        if (arr.length < 4) {
            throw new IllegalArgumentException("Array size should be at least 4");
        }
        
        Arrays.sort(arr); // Sort the array in ascending order
        
        return arr[3]; // Fourth smallest element at index 3
    }
}
