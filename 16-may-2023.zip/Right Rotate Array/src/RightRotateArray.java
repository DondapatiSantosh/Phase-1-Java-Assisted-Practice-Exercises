import java.util.Arrays;

public class RightRotateArray {
    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        int rotateSteps = 5;
        
        System.out.println("Original Array: " + Arrays.toString(arr));
        
        rightRotateArray(arr, rotateSteps);
        
        System.out.println("Rotated Array: " + Arrays.toString(arr));
    }
    
    public static void rightRotateArray(int[] arr, int rotateSteps) {
        int length = arr.length;
        rotateSteps %= length; // Adjust the number of steps if it's greater than the array length
        
        reverseArray(arr, 0, length - 1);
        reverseArray(arr, 0, rotateSteps - 1);
        reverseArray(arr, rotateSteps, length - 1);
    }
    
    public static void reverseArray(int[] arr, int start, int end) {
        while (start < end) {
            int temp = arr[start];
            arr[start] = arr[end];
            arr[end] = temp;
            start++;
            end--;
        }
    }
}
