
public class ConstructorTypes {

	
		
		    private String name;
		    private int age;

		    // Default constructor
		    public ConstructorTypes() {
		        this.name = "Dondapati Ethel";
		        this.age = 22;
		    }

		    // Parameterized constructor
		    public ConstructorTypes(String name, int age) {
		        this.name = name;
		        this.age = age;
		    }

		    // Copy constructor
		    public ConstructorTypes(ConstructorTypes other) {
		        this.name = other.name;
		        this.age = other.age;
		    }

		    public String getName() {
		        return name;
		    }

		    public int getAge() {
		        return age;
		    }

		    public static void main(String[] args) {
		        // Create objects using different constructors
		        ConstructorTypes defaultConstructor = new ConstructorTypes();
		        ConstructorTypes parameterizedConstructor = new ConstructorTypes("Dondapati Santosh", 23);
		        ConstructorTypes copyConstructor = new ConstructorTypes(defaultConstructor);

		        // Print object details
		        System.out.println("Default constructor: name=" + defaultConstructor.getName() + ", age=" + defaultConstructor.getAge());
		        System.out.println("Parameterized constructor: name=" + parameterizedConstructor.getName() + ", age=" + parameterizedConstructor.getAge());
		        System.out.println("Copy constructor: name=" + copyConstructor.getName() + ", age=" + copyConstructor.getAge());
		    }
		

	}


