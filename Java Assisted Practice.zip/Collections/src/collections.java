import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

		public class collections {
		    public static void main(String[] args) {
		        // ArrayList
		        List<String> arrayList = new ArrayList<>();
		        arrayList.add("apple");
		        arrayList.add("banana");
		        arrayList.add("cherry");
		        System.out.println("ArrayList: " + arrayList);

		        // LinkedList
		        List<String> linkedList = new LinkedList<>();
		        linkedList.add("apple");
		        linkedList.add("banana");
		        linkedList.add("cherry");
		        System.out.println("LinkedList: " + linkedList);

		        // HashSet
		        Set<String> hashSet = new HashSet<>();
		        hashSet.add("apple");
		        hashSet.add("banana");
		        hashSet.add("cherry");
		        System.out.println("HashSet: " + hashSet);

		        // TreeSet
		        Set<String> treeSet = new TreeSet<>();
		        treeSet.add("apple");
		        treeSet.add("banana");
		        treeSet.add("cherry");
		        System.out.println("TreeSet: " + treeSet);

		        // HashMap
		        Map<String, Integer> hashMap = new HashMap<>();
		        hashMap.put("apple", 1);
		        hashMap.put("banana", 2);
		        hashMap.put("cherry", 3);
		        System.out.println("HashMap: " + hashMap);

		        // TreeMap
		        Map<String, Integer> treeMap = new TreeMap<>();
		        treeMap.put("apple", 1);
		        treeMap.put("banana", 2);
		        treeMap.put("cherry", 3);
		        System.out.println("TreeMap: " + treeMap);

		        // LinkedHashMap
		        Map<String, Integer> linkedHashMap = new LinkedHashMap<>();
		        linkedHashMap.put("apple", 1);
		        linkedHashMap.put("banana", 2);
		        linkedHashMap.put("cherry", 3);
		        System.out.println("LinkedHashMap: " + linkedHashMap);

		        // Iterate over collections
		        System.out.println("Iterating over collections:");
		        Iterator<String> it1 = arrayList.iterator();
		        while (it1.hasNext()) {
		            System.out.print(it1.next() + " ");
		        }
		        System.out.println();

		        Iterator<String> it2 = hashSet.iterator();
		        while (it2.hasNext()) {
		            System.out.print(it2.next() + " ");
		        }
		        System.out.println();

		        Iterator<String> it3 = treeSet.iterator();
		        while (it3.hasNext()) {
		            System.out.print(it3.next() + " ");
		        }
		        System.out.println();

		        for (String key : hashMap.keySet()) {
		            System.out.println(key + ": " + hashMap.get(key));
		        }

		        for (String key : treeMap.keySet()) {
		            System.out.println(key + ": " + treeMap.get(key));
		        }

		        for (String key : linkedHashMap.keySet()) {
		            System.out.println(key + ": " + linkedHashMap.get(key));
		        }
		    }
		


	}


