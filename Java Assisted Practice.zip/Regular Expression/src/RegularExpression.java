import java.util.regex.Matcher;
import java.util.regex.Pattern;

		public class RegularExpression {
		    public static void main(String[] args) {
		        String input = "The quick brown fox jumps over the lazy dog.";
		        String regex = "(?i)the.*?dog";

		        // compile the regular expression
		        Pattern pattern = Pattern.compile(regex);

		        // match the pattern against the input string
		        Matcher matcher = pattern.matcher(input);

		        // find the first match and print it
		        if (matcher.find()) {
		            System.out.println("Found match: " + matcher.group());
		        } else {
		            System.out.println("No match found.");
		        }
		    }
		}




