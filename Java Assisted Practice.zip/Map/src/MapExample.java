import java.util.*;

public class MapExample {
    public static void main(String[] args) {
        // Create a HashMap and add some key-value pairs
        Map<String, Integer> map = new HashMap<>();
        map.put("Ethel", 22);
        map.put("Dharam", 25);
        map.put("Santosh", 27);

        // Print the map
        System.out.println("Map: " + map);

        // Accessing values using keys
        System.out.println("Age of Ethel: " + map.get("Ethel"));
        System.out.println("Age of Dharam: " + map.get("Dharam"));
        System.out.println("Age of Santosh: " + map.get("Santosh"));

        // Checking if a key exists
        System.out.println("Is Ethel present in the map? " + map.containsKey("Ethel"));
        System.out.println("Is Donsan present in the map? " + map.containsKey("Donsan"));

        // Removing a key-value pair
        map.remove("Santosh");
        System.out.println("Map after removing Santosh: " + map);

        // Iterating over the map
        System.out.println("Iterating over the map:");
        for (Map.Entry<String, Integer> entry : map.entrySet()) {
            System.out.println(entry.getKey() + " is " + entry.getValue() + " years old.");
        }
    }
}

