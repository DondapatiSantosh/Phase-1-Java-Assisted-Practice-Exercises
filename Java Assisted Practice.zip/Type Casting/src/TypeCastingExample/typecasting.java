package TypeCastingExample;

public class typecasting {

	public static void main(String[] args) {
		
		    
		        // Implicit type casting
		        int x = 11;
		        double y = x; // Implicitly casts int to double
		        System.out.println("x = " + x + ", y = " + y);

		        // Explicit type casting
		        double z = 12.543;
		        int a = (int) z; // Explicitly casts double to int
		        System.out.println("z = " + z + ", a = " + a);
		    }
		

	}

