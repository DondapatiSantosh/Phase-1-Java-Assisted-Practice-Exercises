
public class ArrayImplementation {

	public static void main(String[] args) {
		
		        // declaring an array of integers
		        int[] intArray;

		        // allocating memory for 5 integers
		        intArray = new int[5];

		        // initializing the array elements
		        intArray[0] = 10;
		        intArray[1] = 20;
		        intArray[2] = 30;
		        intArray[3] = 40;
		        intArray[4] = 50;

		        // accessing array elements using for loop
		        System.out.println("Array elements using for loop:");
		        for (int i = 0; i < intArray.length; i++) {
		            System.out.println("Element at index " + i + ": " + intArray[i]);
		        }

		        // accessing array elements using enhanced for loop
		        System.out.println("Array elements using enhanced for loop:");
		        for (int element : intArray) {
		            System.out.println("Element: " + element);
		        }

		        // declaring and initializing an array in one line
		        String[] stringArray = {"apple", "banana", "orange"};

		        // accessing array elements using for loop
		        System.out.println("String array elements using for loop:");
		        for (int i = 0; i < stringArray.length; i++) {
		            System.out.println("Element at index " + i + ": " + stringArray[i]);
		        }

		        // accessing array elements using enhanced for loop
		        System.out.println("String array elements using enhanced for loop:");
		        for (String element : stringArray) {
		            System.out.println("Element: " + element);
		        }
		    }
		

	}


