
public class accessmodifier {

	public static void main(String[] args) {
				// Create objects of MyClass
		        MyClass obj1 = new MyClass();
		        MyClass obj2 = new MyClass();

		        // Call methods on obj1
		        obj1.publicMethod();    
		        obj1.protectedMethod(); 
		        obj1.defaultMethod();   
		        

		        // Call methods on obj2
		        obj2.publicMethod();    
		        obj2.protectedMethod(); 
		        obj2.defaultMethod();   
		        
		    }
		}

		class MyClass {
		    public void publicMethod() {
		        System.out.println("This is a public method.");
		    }

		    protected void protectedMethod() {
		        System.out.println("This is a protected method.");
		    }

		    void defaultMethod() {
		        System.out.println("This is a default method.");
		    }

		    private void privateMethod() {
		        System.out.println("This is a private method.");
		    }
		
	}

