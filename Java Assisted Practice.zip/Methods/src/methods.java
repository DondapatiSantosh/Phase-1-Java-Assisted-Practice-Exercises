
public class methods {

	public static void main(String[] args) {
		
		        // Create an object of MyClass
		        MyClass obj = new MyClass();

		        // Call the methods in different ways
		        int result1 = obj.addNumbers(5, 7);                // Call with arguments and store the result
		        obj.printMessage("Hello, world!");                 // Call with a string argument
		        double result2 = obj.calculateCircleArea(2.5);     // Call with a double argument and store the result
		        obj.printMessage();                                // Call with no arguments
		        obj.printNumbers(1, 2, 3, 4, 5);                    // Call with multiple arguments of the same type
		        obj.printNumbers("Numbers: ", 1, 2, 3, 4, 5);       // Call with a string argument followed by multiple arguments of the same type
		        obj.printNumbers("Numbers: ", new int[] {1, 2, 3}); // Call with a string argument followed by an array argument
		    }
		}

		class MyClass {
		    public int addNumbers(int a, int b) {
		        int sum = a + b;
		        return sum;
		    }

		    public void printMessage(String message) {
		        System.out.println(message);
		    }

		    public double calculateCircleArea(double radius) {
		        double area = Math.PI * radius * radius;
		        return area;
		    }

		    public void printMessage() {
		        System.out.println("This is a default message.");
		    }

		    public void printNumbers(int... numbers) {
		        for (int num : numbers) {
		            System.out.print(num + " ");
		        }
		        System.out.println();
		    }

		    public void printNumbers(String message, int... numbers) {
		        System.out.print(message);
		        for (int num : numbers) {
		            System.out.print(num + " ");
		        }
		        System.out.println();
		    }

		    public void printNumbers(String message, int[] numbers) {
		        System.out.print(message);
		        for (int num : numbers) {
		            System.out.print(num + " ");
		        }
		        System.out.println();
		    }
		
	

	}


