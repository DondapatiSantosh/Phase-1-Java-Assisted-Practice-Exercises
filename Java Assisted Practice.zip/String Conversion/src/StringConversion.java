public class StringConversion {
    public static void main(String[] args) {
        String str = "Hello, world!";
        System.out.println("Original string: " + str);

        StringBuffer stringBuffer = new StringBuffer(str);
        System.out.println("StringBuffer: " + stringBuffer);

        StringBuilder stringBuilder = new StringBuilder(str);
        System.out.println("StringBuilder: " + stringBuilder);
    }
}
