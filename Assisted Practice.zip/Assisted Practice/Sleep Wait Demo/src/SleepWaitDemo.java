public class SleepWaitDemo {
    
    public static void main(String[] args) {
        Object lock = new Object(); // Object to use as a lock
        
        // Thread to demonstrate sleep()
        Thread sleepThread = new Thread(() -> {
            try {
                System.out.println("Sleeping for 5 seconds...");
                Thread.sleep(5000); // Sleep for 5 seconds
                System.out.println("Done sleeping!");
            } catch (InterruptedException e) {
                System.out.println("Interrupted while sleeping!");
            }
        });
        
        // Thread to demonstrate wait()
        Thread waitThread = new Thread(() -> {
            synchronized (lock) {
                try {
                    System.out.println("Waiting...");
                    lock.wait(); // Wait for notification from another thread
                    System.out.println("Done waiting!");
                } catch (InterruptedException e) {
                    System.out.println("Interrupted while waiting!");
                }
            }
        });
        
        // Start the threads
        sleepThread.start();
        waitThread.start();
        
        // Notify the waitThread after 3 seconds
        try {
            Thread.sleep(3000);
            synchronized (lock) {
                lock.notify(); // Notify the waitThread
            }
        } catch (InterruptedException e) {
            System.out.println("Interrupted while notifying!");
        }
    }
}

