public class Exception{
    
    public static void main(String[] args) {
        try {
            int num = divide(10, 0);
            System.out.println("Result: " + num);
        } catch (ArithmeticException e) {
            System.out.println("Caught exception: " + e.getMessage());
        } finally {
            System.out.println("Finally block executed!");
        }
        
        try {
            int[] arr = {1, 2, 3};
            int num = arr[3];
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Caught exception: " + e.getMessage());
        } finally {
            System.out.println("Finally block executed!");
        }
        
        try {
            validateAge(15);
        } catch (InvalidAgeException e) {
            System.out.println("Caught exception: " + e.getMessage());
        } finally {
            System.out.println("Finally block executed!");
        }
        
        try {
            int num = divideByNegative(10, -2);
            System.out.println("Result: " + num);
        } catch (NegativeNumberException e) {
            System.out.println("Caught exception: " + e.getMessage());
        } finally {
            System.out.println("Finally block executed!");
        }
    }
    
    public static int divide(int a, int b) throws ArithmeticException {
        if (b == 0) {
            throw new ArithmeticException("Cannot divide by zero!");
        }
        return a / b;
    }
    
    public static int divideByNegative(int a, int b) throws NegativeNumberException {
        if (b < 0) {
            throw new NegativeNumberException("Cannot divide by negative number!");
        }
        return a / b;
    }
    
    public static void validateAge(int age) throws InvalidAgeException {
        if (age < 18) {
            throw new InvalidAgeException("Age must be at least 18!");
        }
    }
}

class InvalidAgeException extends Exception {
    public InvalidAgeException(String message) {
        super(message);
    }
}

class NegativeNumberException extends Throwable {
    public NegativeNumberException(String message) {
        super(message);
    }
}
